package com.example.queeze;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    /**
     *
     * Works when "VIEW RESULTS button is clicked
     *
     * Displays final score
     * @param view
     */

    public void  submit(View view){
        int score=0;

        RadioButton answer1 = findViewById(R.id.option_1A);
        RadioButton wrongAnswer1B = findViewById(R.id.option_1B);
        RadioButton wrongAnswer1C = findViewById(R.id.option_1C);
        RadioButton wrongAnswer1D = findViewById(R.id.option_1D);

        boolean is_1_right = answer1.isChecked();

        if (is_1_right){
            score += 2;

        }

        else{
            if (wrongAnswer1B.isChecked()){
                wrongAnswer1B.setBackgroundColor(Color.parseColor("#ff002b"));
            }
            else if (wrongAnswer1C.isChecked()){
                wrongAnswer1C.setBackgroundColor(Color.parseColor("#ff002b"));
            }
            else if (wrongAnswer1D.isChecked()) {
                wrongAnswer1D.setBackgroundColor(Color.parseColor("#ff002b"));
            }
        }
        answer1.setBackgroundColor(Color.parseColor("#00ff66"));

        EditText answer2 = findViewById(R.id.answer_2);
        String is_2_right = answer2.getText().toString();
        if (is_2_right.equals("Australia")){
            score += 2;
        }

        else{
            answer2.setTextColor(Color.RED);
        }

        RadioButton answer3 = findViewById(R.id.option_3C);
        RadioButton wrongAnswer3A = findViewById(R.id.option_3A);
        RadioButton wrongAnswer3B = findViewById(R.id.option_3B);
        RadioButton wrongAnswer3D = findViewById(R.id.option_3D);

        boolean is_3_right = answer3.isChecked();

        if (is_3_right){
            score += 2;
        }

        else{
            if (wrongAnswer3B.isChecked()){
                wrongAnswer3B.setBackgroundColor(Color.parseColor("#ff002b"));
            }
            else if (wrongAnswer3A.isChecked()){
                wrongAnswer3A.setBackgroundColor(Color.parseColor("#ff002b"));
            }
            else if (wrongAnswer3D.isChecked()) {
                wrongAnswer3D.setBackgroundColor(Color.parseColor("#ff002b"));
            }
        }
        answer3.setBackgroundColor(Color.parseColor("#00ff66"));


        CheckBox answer4 = findViewById(R.id.option_4B);
        CheckBox answer_4 = findViewById(R.id.option_4C);
        CheckBox wrongAnswer4A = findViewById(R.id.option_4A);
        CheckBox wrongAnswer4D = findViewById(R.id.option_4D);

        boolean is_4_right = answer4.isChecked();
        boolean is_4_right_Too = answer_4.isChecked();
        boolean is_4A_checked = wrongAnswer4A.isChecked();
        boolean is_4D_checked = wrongAnswer4D.isChecked();

        if (is_4_right && is_4_right_Too && !is_4A_checked && !is_4D_checked){
            score += 2;
        }
        else{
            if (is_4A_checked){
                wrongAnswer4A.setBackgroundColor(Color.parseColor("#ff002b"));
            }
            else if (is_4D_checked) {
                wrongAnswer4D.setBackgroundColor(Color.parseColor("#ff002b"));
            }
        }
        answer4.setBackgroundColor(Color.parseColor("#00ff66"));
        answer_4.setBackgroundColor(Color.parseColor("#00ff66"));

        RadioButton answer5 = findViewById(R.id.option_5D);

        RadioButton wrongAnswer5A = findViewById(R.id.option_5A);
        RadioButton wrongAnswer5B = findViewById(R.id.option_5B);
        RadioButton wrongAnswer5C = findViewById(R.id.option_5C);

        boolean is_5_right = answer5.isChecked();

        if (is_5_right){
            score += 2;
        }
        else{
            if (wrongAnswer5B.isChecked()){
                wrongAnswer5B.setBackgroundColor(Color.parseColor("#ff002b"));
            }
            else if (wrongAnswer5C.isChecked()){
                wrongAnswer5C.setBackgroundColor(Color.parseColor("#ff002b"));
            }
            else if (wrongAnswer5A.isChecked()) {
                wrongAnswer5A.setBackgroundColor(Color.parseColor("#ff002b"));
            }
        }
        answer5.setBackgroundColor(Color.parseColor("#00ff66"));

        if(score==10) {
            Toast.makeText(this,"Woohoo! Bull's Eye \nScore = " + score + "/10" , Toast.LENGTH_LONG).show();

        }
        else{
            Toast.makeText(this,"Score = " + score + "/10" + "\nCome back when you're ready :)",Toast.LENGTH_LONG).show();
        }
    }

}
